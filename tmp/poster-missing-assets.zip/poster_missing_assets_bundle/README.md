# Missing Poster Assets for `Poster-Owli-AI-Apps`

Dieses Paket bereitet die Zielstruktur für die im Poster erwarteten Assets vor.

Enthalten ist der QR-Code:

- `assets/qr/sightcity-qr.png` -> `https://owli-ai.com/sightcity/`

Die sechs App-Bilddateien sind in der aktuellen Ausführungsumgebung nicht direkt als vollständige Binärdateien herunterladbar gewesen. Nutze daher eines der Skripte unter `scripts/`, um sie aus einem lokalen Clone von `owli-ai-landing` oder alternativ von der veröffentlichten Website zu kopieren.

## Zielpfade im Poster-Repo

| Ziel im Poster-Repo | Quelle im Website-Repo |
|---|---|
| `assets/figures/magnify-logo.webp` | `owli-ai-landing/public/apps/magnify/logo-1024-transparent.webp` |
| `assets/figures/magnify-screenshot.jpg` | `owli-ai-landing/public/apps/magnify/screenshot-02.jpg` |
| `assets/figures/assist-logo.webp` | `owli-ai-landing/public/apps/assist/logo-1024-transparent.webp` |
| `assets/figures/assist-screenshot.webp` | `owli-ai-landing/public/apps/assist/screenshot-05.webp` |
| `assets/figures/way-buddy-logo.webp` | `owli-ai-landing/public/apps/way-buddy/logo-1024-transparent.webp` |
| `assets/figures/way-buddy-screenshot.webp` | `owli-ai-landing/public/apps/way-buddy/screenshot-01.webp` |

## Empfohlener lokaler Workflow

Lege beide Repos nebeneinander ab:

```text
parent/
  owli-ai-landing/
  Poster-Owli-AI-Apps/
```

Dann im Poster-Repo ausführen:

### PowerShell

```powershell
.\scripts\copy-missing-assets.ps1 -LandingRepo ..\owli-ai-landing -PosterRepo .
```

### Bash

```bash
bash scripts/copy-missing-assets.sh ../owli-ai-landing .
```

Danach:

```bash
make check
make preview
```
